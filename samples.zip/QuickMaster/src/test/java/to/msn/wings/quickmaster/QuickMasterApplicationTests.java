package to.msn.wings.quickmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
