package to.msn.wings.quickmaster.models;

public interface BookTitleOnly {
    String getTitle();
}
