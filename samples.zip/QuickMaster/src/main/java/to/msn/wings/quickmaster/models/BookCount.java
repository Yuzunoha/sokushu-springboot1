package to.msn.wings.quickmaster.models;

public interface BookCount {
    String getPublisher();
    int getNumber();
}